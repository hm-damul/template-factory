Assets for 20260215-000641-freelancer-consultant-landing-
Topic: freelancer-consultant-landing-page

- icon_wallet_lock.svg: simple vector icon
