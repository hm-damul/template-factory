Assets for 20260215-143622-web3-smart-contract-audit-chec
Topic: Web3-Smart-Contract-Audit-Checklist

- icon_wallet_lock.svg: simple vector icon
