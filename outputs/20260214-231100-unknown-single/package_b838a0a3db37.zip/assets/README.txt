Assets for 20260214-231100-unknown-single
Topic: unknown_single

- icon_wallet_lock.svg: simple vector icon
