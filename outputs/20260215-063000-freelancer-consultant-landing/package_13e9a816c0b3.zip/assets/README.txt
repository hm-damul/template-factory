Assets for 20260215-063000-freelancer-consultant-landing-
Topic: freelancer-consultant-landing-page

- icon_wallet_lock.svg: simple vector icon
