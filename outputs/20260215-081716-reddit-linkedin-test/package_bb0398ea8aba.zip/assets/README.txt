Assets for 20260215-081716-reddit-linkedin-test
Topic: Reddit_LinkedIn_Test

- icon_wallet_lock.svg: simple vector icon
