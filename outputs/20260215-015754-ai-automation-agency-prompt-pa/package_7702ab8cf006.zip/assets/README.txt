Assets for 20260215-015754-ai-automation-agency-prompt-pa
Topic: AI-Automation-Agency-Prompt-Pack

- icon_wallet_lock.svg: simple vector icon
