Assets for 20260215-125053-global-merchant-crypto-checkou
Topic: Global Merchant Crypto Checkout Blueprint (No Bank Friction)

- icon_wallet_lock.svg: simple vector icon
