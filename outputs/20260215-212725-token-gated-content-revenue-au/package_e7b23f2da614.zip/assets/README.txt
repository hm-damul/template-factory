Assets for 20260215-212725-token-gated-content-revenue-au
Topic: Token-Gated Content + Revenue Automation for Web3 Communities

- icon_wallet_lock.svg: simple vector icon
