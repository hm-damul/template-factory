Assets for 20260215-014951-automated-crypto-tax-reporting
Topic: Automated-Crypto-Tax-Reporting-Tool

- icon_wallet_lock.svg: simple vector icon
