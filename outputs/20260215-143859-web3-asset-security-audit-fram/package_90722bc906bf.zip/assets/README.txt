Assets for 20260215-143859-web3-asset-security-audit-fram
Topic: Web3-Asset-Security-Audit-Framework

- icon_wallet_lock.svg: simple vector icon
