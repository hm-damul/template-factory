Assets for 20260215-004917-high-ticket-service-automation
Topic: High-Ticket-Service-Automation-Guide

- icon_wallet_lock.svg: simple vector icon
