Assets for 20260215-074829-freelancer-consultant-landing
Topic: freelancer-consultant-landing-page

- icon_wallet_lock.svg: simple vector icon
