MIT License

Copyright (c) 2026 {product_id}

Permission is hereby granted...
