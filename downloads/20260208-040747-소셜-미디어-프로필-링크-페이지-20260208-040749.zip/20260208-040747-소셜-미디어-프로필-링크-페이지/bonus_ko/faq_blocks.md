# FAQ Blocks (Copy/Paste)

## Does this work without a huge audience?
Yes. Use the metrics template and target realistic conversion (1.2–2.8%).

## Which networks/currencies are supported?
List your supported coins and networks clearly. Confusion here is the #1 support driver.

## How do I receive the file after paying?
You get an automated status check + a gated download link (signed token).

## Refund policy?
Define it upfront. Common options: (a) refund before download, (b) credit after download, (c) manual review for wrong-network payments.
