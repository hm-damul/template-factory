# Pricing Copy Blocks

Use these blocks to improve landing page clarity + perceived value.

## Basic ($39)
- Premium PDF guide (professionally formatted)
- Key diagrams + checklists
- Deterministic build per product_id

## Bundle ($59)
- Everything in Basic
- Prompt pack + worksheets + scripts
- 30-day promo calendar

## Pro ($79)
- Everything in Bundle
- Benchmarks + troubleshooting matrix
- Launch plan + support macros

**Pro tip:** show *counts* (diagrams, bonus files, promo assets) as proof.
