# 20260213-102922-minimalist-saas-landing-page - 디지털 제품

이것은 20260213-102922-minimalist-saas-landing-page 주제로 생성된 디지털 제품입니다.

## 포함된 파일
- `index.html`: 메인 랜딩 페이지
- `generation_report.json`: 제품 생성 보고서

## 사용 방법
`index.html` 파일을 웹 브라우저에서 직접 열어보세요.

## 지원
문의 사항은 `support@example.com`으로 연락주세요.
